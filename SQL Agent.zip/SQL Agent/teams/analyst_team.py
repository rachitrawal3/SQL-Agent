# teams/analyst_team.py

from autogen_agentchat.teams import SelectorGroupChat
from autogen_agentchat.conditions import (
    MaxMessageTermination,
    TextMentionTermination,
    TokenUsageTermination
)
from models.openaimodel import model_client_o4

# Import agent factories
from agents.sql_agent import create_sql_agent
from agents.sql_output import create_sql_output_formatter_agent
from agents.chart_gen_agent import create_chart_gen_agent
from agents.insight_gen_agent import create_insight_gen_agent

# Termination conditions
text_msg_termination = TextMentionTermination("ALL_STEPS_COMPLETED")
max_msg_termination  = MaxMessageTermination(max_messages=20)
max_tokens           = TokenUsageTermination(max_total_token=150000)
combined_termination = (
    text_msg_termination
    | max_msg_termination
    | max_tokens
)

# Selector prompt
selector_prompt = r"""
You are orchestrating a 4-agent data analysis & visualization pipeline. On each turn, choose exactly one agent to act next.

Agents:
{roles}

Conversation so far:
{history}

Pipeline Flow:
1. Always start with the SQL Agent – it must fetch and return the required tabular data (raw format).
2. Once raw data is available, send it first to the **Chart Generation Executor Agent**.
3. After the chart is generated, send the **same raw data** to both:
   - SQL Output Formatter Agent – to convert it into a clean markdown table.
   - Insight Generation Agent – to write insights based on the raw data.

Do NOT change or reorder these steps.

Selection Rules:
- If the user just asked a new question or requested data → SQL Agent.
- If the user asked a **follow-up question** (e.g. "previous query", "those results", "the above suppliers", "same data", "continue") → SQL Agent, because it has MEMORY of past context.
- If SQL output is now available → Chart Generation Executor Agent.
- After the chart is saved (look for “CHART_SAVED_AT: ...”) → SQL Output Formatter Agent.
- Once chart is saved and data is available → Insight Generation Agent.
- Do NOT skip or repeat steps.
- Run only one agent per turn.
- Reply ONLY with the selected agent’s name — no extra text or explanation.

If you are ever uncertain which agent to pick, ALWAYS default to → SQL Agent.

Examples:
User: "Show me the top 5 customers by total purchases."  
→ Next Agent: SQL Agent

User: "Now show me the regions of these suppliers." (follow-up)  
→ Next Agent: SQL Agent

User: "Visualize the results." (SQL already gave raw data)  
→ Next Agent: Chart Generation Executor Agent
"""

def make_analysis_team(extra_context: str | None = None) -> SelectorGroupChat:
    """
    Create a brand-new SelectorGroupChat instance on demand.
    Accepts extra_context (e.g., Redis memory history) to inject into SQL Agent’s system prompt.
    Ensures each agent is freshly instantiated so internal queues bind to the current loop/thread.
    """

    return SelectorGroupChat(
        participants=[
            create_sql_agent(extra_context=extra_context),   # pass memory here
            create_chart_gen_agent(),
            create_sql_output_formatter_agent(),
            create_insight_gen_agent(),
        ],
        model_client=model_client_o4,
        termination_condition=combined_termination,
        selector_prompt=selector_prompt,
        allow_repeated_speaker=True,
    )
