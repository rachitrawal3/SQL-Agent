# main_fixed.py
import os
import re
import time
import uuid
import logging
import shutil
import asyncio
import threading
from typing import Optional, Dict, Any

from fastapi import FastAPI, APIRouter, HTTPException, Request, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from autogen_core import EVENT_LOGGER_NAME
from autogen_core.logging import LLMCallEvent
from autogen_agentchat.messages import TextMessage
from teams.analyst_team import make_analysis_team
from db import InMemoryDB  # your provided implementation (pickle-based)

# --- Keep compatibility with your original default session id ---
SESSION_ID = "default_user"

# ----------------- Configuration -----------------
root_dir = os.getcwd()
# Charts are saved directly in the project root (e.g. TATA_VIZ_agent\chart_bar_xxx.png)
CHART_OUTPUT_DIR = root_dir
RECENT_SECONDS = 120

# Ensure directory exists
os.makedirs(CHART_OUTPUT_DIR, exist_ok=True)

# ----------------- Logging & Token Tracker -----------------
class LLMUsageTracker(logging.Handler):
    def __init__(self):
        super().__init__()
        self.reset()

    def emit(self, record):
        if isinstance(record.msg, LLMCallEvent):
            evt = record.msg
            self._prompt += getattr(evt, "prompt_tokens", 0) or 0
            self._comp += getattr(evt, "completion_tokens", 0) or 0

    def reset(self):
        self._prompt = 0
        self._comp = 0

    @property
    def prompt_tokens(self):
        return self._prompt

    @property
    def completion_tokens(self):
        return self._comp


logging.basicConfig(level=logging.INFO)
_event_logger = logging.getLogger(EVENT_LOGGER_NAME)
_event_logger.setLevel(logging.INFO)
_event_logger.handlers = []


# ----------------- Thread-safe wrapper around your InMemoryDB -----------------
class ThreadSafeInMemoryDB:
    def __init__(self, inner: InMemoryDB):
        self._inner = inner
        self._lock = threading.RLock()

    def add_message(self, session_id: str, message: dict):
        with self._lock:
            return self._inner.add_message(session_id, message)

    def get_messages(self, session_id: str, limit: Optional[int] = None):
        with self._lock:
            return self._inner.get_messages(session_id, limit=limit)

    def get_history(self, session_id: str, n: int = 5):
        with self._lock:
            return self._inner.get_history(session_id, n=n)


memory = ThreadSafeInMemoryDB(InMemoryDB())

# ----------------- Models -----------------
class AnalyzeRequest(BaseModel):
    query: str
    session_id: Optional[str] = None

class AnalyzeResponse(BaseModel):
    insight: Optional[str] = None
    chart_path: Optional[str] = None
    table_md: Optional[str] = None
    token_usage: Optional[Dict[str, int]] = None
    session_id: Optional[str] = None


# ----------------- FastAPI app -----------------
app = FastAPI(title="Tata Viz Backend (fixed)", version="1.0.0")
router = APIRouter()

# Serve charts via /charts
app.mount("/charts", StaticFiles(directory=CHART_OUTPUT_DIR), name="charts")

# ----------------- Helper utilities -----------------
async def _exists(path: str) -> bool:
    return await asyncio.to_thread(os.path.exists, path)

async def _getsize(path: str) -> int:
    return await asyncio.to_thread(os.path.getsize, path)

async def _getmtime(path: str) -> float:
    return await asyncio.to_thread(os.path.getmtime, path)

async def _copy2(src: str, dst: str):
    return await asyncio.to_thread(shutil.copy2, src, dst)

async def _is_path_in_chart_dir(path: str) -> bool:
    try:
        chart_dir_abs = os.path.abspath(CHART_OUTPUT_DIR)
        path_abs = os.path.abspath(path)
        common = os.path.commonpath([chart_dir_abs, path_abs])
        return common == chart_dir_abs
    except Exception:
        return False

async def _is_recent_file(path: str, max_age_seconds: int = RECENT_SECONDS) -> bool:
    try:
        if not await _exists(path):
            return False
        if await _getsize(path) == 0:
            return False
        age = time.time() - await _getmtime(path)
        return age <= max_age_seconds
    except Exception:
        return False

async def _copy_into_chart_dir(src_path: str) -> Optional[str]:
    try:
        if not await _exists(src_path):
            return None
        basename = os.path.basename(src_path)
        name, ext = os.path.splitext(basename)
        dest = os.path.join(CHART_OUTPUT_DIR, f"{name}_{uuid.uuid4().hex}{ext}")
        await _copy2(src_path, dest)
        logging.info("Copied chart file into chart dir: %s -> %s", src_path, dest)
        return os.path.abspath(dest)
    except Exception:
        logging.exception("Failed to copy chart into chart dir")
        return None


# ----------------- Core runner -----------------
async def _run_analysis_async(user_query: str, session_id: str):
    history = memory.get_history(session_id, n=5)
    memory.add_message(session_id, {"role": "user", "content": user_query})
    history = memory.get_history(session_id, n=5)
    context = "\n".join([f"{m['role']}: {m['content']}" for m in history])

    team = make_analysis_team(extra_context=context)
    if hasattr(team, "reset"):
        try:
            reset_res = team.reset()
            if asyncio.iscoroutine(reset_res):
                await reset_res
        except Exception:
            logging.exception("Failed to reset team instance")

    local_tracker = LLMUsageTracker()
    local_tracker.reset()
    _event_logger.addHandler(local_tracker)
    try:
        result = await team.run(task=TextMessage(content=user_query, source="user"))
    finally:
        try:
            _event_logger.removeHandler(local_tracker)
        except Exception:
            logging.exception("Failed to remove local LLMUsageTracker")

    chart_path: Optional[str] = None
    insight: str = ""
    table_md: Optional[str] = None

    for msg in getattr(result, "messages", []):
        try:
            content = (
                msg.content if hasattr(msg, "content")
                else getattr(msg, "chat_message", None)
                and getattr(msg.chat_message, "content", None)
            )
        except Exception:
            content = None

        if not isinstance(content, str):
            continue

        content = content.strip()
        source = (getattr(msg, "source", "") or "").lower()

        if source.startswith("insight") or "insight:" in content.lower():
            insight += content + "\n\n"

        if (source.startswith("sql_output") or (content.startswith("|") and "---" in content)) and not table_md:
            table_md = content

        m = re.search(r'CHART_SAVED_AT:\s*[\'"]?(.*?\.png)[\'"]?', content, re.IGNORECASE)
        if m:
            printed = m.group(1).strip().strip('"').strip("'")
            abs_candidate = (
                printed if os.path.isabs(printed)
                else os.path.join(CHART_OUTPUT_DIR, os.path.basename(printed))
            )

            if os.path.isabs(printed) and not await _is_path_in_chart_dir(abs_candidate):
                if await _exists(printed):
                    copied = await _copy_into_chart_dir(printed)
                    if copied:
                        abs_candidate = copied

            if await _is_path_in_chart_dir(abs_candidate) and await _is_recent_file(abs_candidate):
                if not chart_path:
                    chart_path = os.path.abspath(abs_candidate)
                    logging.info("Accepted chart_path: %s", chart_path)

    final_reply = (insight.strip() or "")[:1000]
    memory.add_message(session_id, {"role": "assistant", "content": final_reply})

    token_usage = {
        "prompt_tokens": local_tracker.prompt_tokens,
        "completion_tokens": local_tracker.completion_tokens,
    }

    return AnalyzeResponse(
        insight=insight.strip() or None,
        chart_path=chart_path,
        table_md=table_md,
        token_usage=token_usage,
        session_id=session_id,
    )

async def run_analysis(user_query: str, session_id: str) -> AnalyzeResponse:
    return await _run_analysis_async(user_query, session_id)


# ----------------- FastAPI endpoint -----------------
@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze(req: AnalyzeRequest, request: Request, response: Response):
    session_id = req.session_id or request.headers.get("x-session-id") or SESSION_ID
    try:
        res = await run_analysis(req.query, session_id)
        response.headers["x-session-id"] = session_id
        return res
    except Exception:
        logging.exception("Analysis failed for query: %s", req.query)
        raise HTTPException(status_code=500, detail=f"Internal analysis error")

app.include_router(router)

# ----------------- Run server -----------------
if __name__ == "__main__":
    import uvicorn
    logging.info("Starting Tata Viz Backend (fixed)")
    logging.info("CHART_OUTPUT_DIR=%s", CHART_OUTPUT_DIR)
    uvicorn.run("main_fixed:app", host="0.0.0.0", port=8000, reload=True)
