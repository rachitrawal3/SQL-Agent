import os
import json
from autogen_ext.tools.langchain import LangChainToolAdapter
from langchain_community.tools.sql_database.tool import QuerySQLDatabaseTool
from langchain_community.utilities.sql_database import SQLDatabase
from autogen_agentchat.agents import AssistantAgent
from models.openaimodel import model_client_o4
from autogen_core.model_context import BufferedChatCompletionContext
# === Config path ===
root_dir = os.getcwd()
CONFIG_FILE = os.path.join(root_dir, "configuration.json")


def load_db_url():
    """Load database URL from configuration.json."""
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            config = json.load(f)
        return config.get("DB_URL", None)
    return None


# === Factory to create a fresh SQL agent with PostgreSQL access ===
def create_sql_agent(memory=None, extra_context: str | None = None) -> AssistantAgent:
    """
    Factory function that creates a SQL Agent with PostgreSQL access.
    Memory must be passed in from outside (shared per user/session).
    Optional extra_context is injected into system prompt for continuity.
    """
    pg_uri = load_db_url()
    if not pg_uri:
        raise RuntimeError("Database URL not found in config.json. Please set it via Streamlit UI.")

    # Connect DB
    db = SQLDatabase.from_uri(pg_uri)
    schema = db.get_usable_table_names()

    # Wrap query tool
    query_tool = QuerySQLDatabaseTool(db=db, description="Execute SQL queries on PostgreSQL DB")
    sql_tool = LangChainToolAdapter(query_tool)

    system_msg = f"""
You are a PostgreSQL SQL Agent with conversational memory.

Your responsibilities:
- Translate user questions into accurate PostgreSQL SQL queries.
- Execute queries using the connected database.
- Return results ONLY as a plain markdown table.

Conversational Memory:
- Always use the provided memory to understand follow-up questions.
- Resolve references like "they", "those suppliers", "that region" by looking at the last retrieved result or previous queries in memory.
- Maintain continuity across turns.

Schema Awareness:
- Use only tables and columns from the provided schema:
{schema}
- If the user mentions concepts not directly matching schema table or column names, intelligently map their terms to the correct tables/columns.

Extra Context (from past session, may help interpret follow-up queries):
{extra_context or "No extra context provided."}

Important:
- Return only the result table with headers and rows.
- Do NOT return SQL queries, explanations, or any additional text.
- Keep the output minimal and structured like a markdown table.

Example Output:
| month      | region    | total_sales |
| 2025-07-01 | AMERICA   | 123456.78   |
| 2025-07-01 | ASIA      | 234567.89   |
| 2025-08-01 | AMERICA   | 223344.55   |
| 2025-08-01 | ASIA      | 245678.99   |
    """

    return AssistantAgent(
        name="sql_agent",
        model_client=model_client_o4,
        tools=[sql_tool],
        memory=memory,  # ✅ injected memory from outside
        model_context=BufferedChatCompletionContext(buffer_size=10),
        system_message=system_msg,
    )
