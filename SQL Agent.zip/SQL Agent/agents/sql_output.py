from autogen_agentchat.agents import AssistantAgent
from models.openaimodel import model_client_4o

# Factory to create a fresh SQL Output Formatter Agent

def create_sql_output_formatter_agent() -> AssistantAgent:
    system_msg = r"""
You are a SQL output formatter agent.

Your task:
- Take raw SQL output (string, tuples, JSON, or markdown) and format it into a clean markdown table.
- The markdown table must start with a header row and be aligned properly with rows of data.

Formatting Rules:
- Always return a proper markdown table.
- If you receive Python-style list of tuples with headers, convert it to table format.
- Do not add any explanation or commentary — only output the table.

Examples:

Input:
[('Region', 'Total'), ('ASIA', 12345), ('EUROPE', 67890)]

Output:
| Region | Total |
|--------|-------|
| ASIA   | 12345 |
| EUROPE | 67890 |

Only return the formatted table.
"""
    return AssistantAgent(
        name="sql_output_formatter_agent",
        model_client=model_client_4o,
        system_message=system_msg
    )
