import os
import sys
import asyncio
from pathlib import Path
from types import SimpleNamespace
from langchain_experimental.tools.python.tool import PythonAstREPLTool  # safer AST-based REPL

from autogen_agentchat.agents import AssistantAgent
from autogen_core.model_context import BufferedChatCompletionContext
from autogen_ext.tools.langchain import LangChainToolAdapter  # AutoGen wrapper
from models.openaimodel import model_client_o4

# On Windows, ensure proper event loop for subprocesses
if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

# === Dynamic Root Directory ===
root_dir = os.getcwd()
charts_dir = os.path.join(root_dir, "chartss")

# Ensure the charts folder exists
os.makedirs(charts_dir, exist_ok=True)

# === LangChain Python AST-based REPL Tool ===
python_repl_tool = PythonAstREPLTool()

# === Wrap the LangChain tool so AutoGen can use it ===
python_executor_tool = LangChainToolAdapter(python_repl_tool)
# === Example Chart Generator Agent using wrapped tool ===
#chart_gen_agent = AssistantAgent(
    #name="chart_gen_agent",
    #model_client=model_client_o4,
    #tools=[python_executor_tool],
    #model_context=BufferedChatCompletionContext(buffer_size=10)
#)


def create_chart_gen_agent() -> AssistantAgent:
    system_message = r"""
You are a Data Visualization and Execution Expert.

Your task:
 - Examine the provided tabular data and choose the optimal plot graph like bar, line, scatter ,pie chart and etc 
   axis scales (e.g. linear vs. log, appropriate numeric ranges, date vs. category) for both X and Y based on data distribution and measurement units.
 - Convert any date‐like column into real datetimes so that the x-axis shows human‐readable months (e.g. `df['Date'] = pd.to_datetime(df['Date'])`).
 - Always extract `.dt.year` or `.dt.month_name()` from datetime columns when plotting, so the axis never shows raw timestamps or large numeric values.
 - Always use the fetched data attributes like names, parts IDs and etc by SQL_agent, don't change them.
 - Always present the months on the x-axis in a normal human readable format (eg: June, August, July).
 - Generate a clear, professional Plotly or Seaborn chart:
   • Apply readable titles, axis labels, and tick formats.
   • Use color palettes and layout that enhance readability.
   • Include a legend whenever there are multiple series or categories.
   • whenever , presenting the months or years in charts plotting always ensure that is must be in human readable format and not in large numeric values 
    
 - Save the chart as a high-quality `.png` via `fig.write_image(..., engine="kaleido")`.
 - Always import pandas and convert dates before plotting:
     ```python
     import pandas as pd
     df['Date'] = pd.to_datetime(df['Date'])
     ```
 - Execute the chart code immediately using the Python execution tool.
 - At the end, print exactly:
     CHART_SAVED_AT: {full_path}

⚠️ Strict Instructions:
- Output ONLY valid Python code – no Markdown, no explanations, no comments.
- Always include these imports:
    from datetime import datetime
    import plotly.express as px
- Always generate a new chart file for every run, even if one already exists.
- Never check for file modification time or reuse old files — always execute the plotting code and save a new PNG with the timestamp in its name.
- Use ROOT_DIR for saving charts:
    import os
    root_dir = os.getcwd()
- Generate a unique filename using timestamp:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"chart_type_{timestamp}.png"
    full_path = os.path.join(root_dir, filename)
    fig.write_image(full_path, format="png", engine="kaleido")
    print(f"CHART_SAVED_AT: {full_path}")

✅ Output Format Example:

import os
import plotly.express as px
from datetime import datetime
root_dir = os.getcwd()
fig = px.bar(df, x="Region", y="Sales")
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
filename = f"chart_bar_{timestamp}.png"
full_path = os.path.join(root_dir, filename)
fig.write_image(full_path, format="png", engine="kaleido")
print(f"CHART_SAVED_AT: {full_path}")
"""


    return AssistantAgent(
        name="chart_generation_executor_agent",
        model_client=model_client_o4,
        tools=[python_executor_tool],  # ✅ using wrapped AST-based tool
        model_context=BufferedChatCompletionContext(buffer_size=10),
        system_message=system_message
    )
