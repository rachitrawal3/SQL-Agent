import os
import logging
import pandas as pd
import streamlit as st
import requests
import json
from io import StringIO
from urllib.parse import urljoin
from autogen_core import EVENT_LOGGER_NAME
from autogen_core.logging import LLMCallEvent

# ====== ROOT DIR ======
ROOT_DIR = os.getcwd()
CONFIG_FILE = os.path.join(ROOT_DIR, "configuration.json")
HISTORY_CSV = os.path.join(ROOT_DIR, "queries.csv")

# ====== BACKEND ======
BACKEND_URL = "http://localhost:8000"
ANALYZE_ENDPOINT = "/analyze"
os.makedirs(os.path.dirname(HISTORY_CSV), exist_ok=True)

# ====== Token Usage Tracker ======
class LLMUsageTracker(logging.Handler):
    def __init__(self):
        super().__init__()
        self.reset()
    def emit(self, record):
        if isinstance(record.msg, LLMCallEvent):
            self._prompt += getattr(record.msg, "prompt_tokens", 0)
            self._comp += getattr(record.msg, "completion_tokens", 0)
    def reset(self):
        self._prompt = 0
        self._comp = 0
    @property
    def prompt_tokens(self): return self._prompt
    @property
    def completion_tokens(self): return self._comp

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(EVENT_LOGGER_NAME)
logger.setLevel(logging.INFO)
tracker = LLMUsageTracker()
logger.handlers = [tracker]

# ====== Helper: Parse Markdown Table ======
def markdown_table_to_dataframe(md: str) -> pd.DataFrame:
    try:
        df = pd.read_csv(
            StringIO(md.strip()),
            sep="|",
            skipinitialspace=True
        ).dropna(axis=1, how="all").iloc[1:]
        df.columns = [c.strip() for c in df.columns]
        return df
    except Exception as e:
        st.warning(f"⚠️ Failed to parse table: {e}")
        return None

# ====== Config helpers ======
def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f: return json.load(f)
        except json.JSONDecodeError: return {}
    return {}
def save_config(data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=4)

# ====== Streamlit UI ======
st.set_page_config(page_title="📊 Tata Viz Frontend", layout="centered")
st.title("📊 Tata Viz: Intelligent Data Analysis")

# === DB URL ===
st.subheader("🔐 Database Connection")
config = load_config()
current_db_url = config.get("DB_URL", "")
new_db_url = st.text_input("Enter your database connection URL", value=current_db_url)
if st.button("Save DB URL"):
    if new_db_url.strip():
        config["DB_URL"] = new_db_url.strip()
        save_config(config)
        st.success(f"✅ DB URL saved successfully! Current: {new_db_url.strip()}")
    else:
        st.warning("⚠️ Please enter a valid DB URL.")

# === Initialize chat history ===
if "messages" not in st.session_state:
    st.session_state.messages = []

# === Display chat history ===
for msg in st.session_state.messages:
    with st.chat_message(msg["role"], avatar=msg.get("avatar", None)):
        if msg["role"] == "assistant":
            # Assistant may have insight, chart, and table
            if msg.get("insight"):
                st.markdown(msg["insight"])
            if msg.get("chart_url"):
                st.image(msg["chart_url"], caption="📊 Generated Chart", use_container_width=True)
            if msg.get("table_md"):
                df = markdown_table_to_dataframe(msg["table_md"])
                if df is not None and not df.empty:
                    st.dataframe(df, use_container_width=True)
            if msg.get("token_info"):
                st.caption(msg["token_info"])
        else:
            st.markdown(msg["content"])

# === User input box ===
if prompt := st.chat_input("Enter your analysis prompt"):
    # Add user msg
    st.session_state.messages.append({"role": "user", "content": prompt, "avatar": "🧑"})

    with st.chat_message("user", avatar="🧑"):
        st.markdown(prompt)

    # Send to backend
    tracker.reset()
    with st.spinner("⏳ Analyzing..."):
        try:
            resp = requests.post(
                urljoin(BACKEND_URL.rstrip("/") + "/", ANALYZE_ENDPOINT.lstrip("/")),
                json={"query": prompt},
                timeout=300
            )
            resp.raise_for_status()
            data = resp.json()
        except requests.exceptions.RequestException as e:
            st.error(f"❌ Backend error: {e}")
            st.stop()
        except ValueError as e:
            st.error(f"❌ Invalid JSON from backend: {e}")
            st.stop()

    if not data:
        st.warning("No response from backend.")
        st.stop()

    # Prepare assistant response
    insight_text = data.get("insight")
    chart_path = data.get("chart_path")
    chart_url = None
    if chart_path:
        chart_filename = os.path.basename(chart_path)
        chart_url = f"{BACKEND_URL.rstrip('/')}/charts/{chart_filename}"

    table_md = data.get("table_md")

    p = data.get("token_usage", {}).get("prompt_tokens", 0)
    c = data.get("token_usage", {}).get("completion_tokens", 0)
    cost = p * (2.50 / 1_000_000) + c * (10.00 / 1_000_000)
    token_info = f"Tokens → Prompt: {p}, Completion: {c} | Estimated cost: ${cost:.6f}"

    assistant_msg = {
        "role": "assistant",
        "avatar": "🤖",
        "insight": insight_text,
        "chart_url": chart_url,
        "table_md": table_md,
        "token_info": token_info,
    }
    st.session_state.messages.append(assistant_msg)

    # Render assistant message
    with st.chat_message("assistant", avatar="🤖"):
        if insight_text:
            st.markdown(insight_text)
        if chart_url:
            st.image(chart_url, caption="📊 Generated Chart", use_container_width=True)
        if table_md:
            df = markdown_table_to_dataframe(table_md)
            if df is not None and not df.empty:
                st.dataframe(df, use_container_width=True)
        st.caption(token_info)

    # Save to CSV history
    try:
        pd.DataFrame([{
            "timestamp": pd.Timestamp.now(),
            "user_query": prompt,
            "insight": insight_text or "",
            "chart_path": chart_path or "",
            "prompt_tokens": p,
            "completion_tokens": c,
            "total_tokens": p + c,
            "total_cost_usd": cost
        }]).to_csv(
            HISTORY_CSV,
            mode='a',
            header=not os.path.exists(HISTORY_CSV),
            index=False
        )
    except Exception as e:
        st.warning(f"Could not write history CSV: {e}")
