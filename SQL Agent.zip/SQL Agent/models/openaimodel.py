from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
import os
from dotenv import load_dotenv
load_dotenv()

model_client_4o= AzureOpenAIChatCompletionClient(
    model="gpt-4o",
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    
   
    )

model_client_o4= AzureOpenAIChatCompletionClient(
    model="o4-mini",
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_o4"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION_o4"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT_o4"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY_o4"),
   
   
    )