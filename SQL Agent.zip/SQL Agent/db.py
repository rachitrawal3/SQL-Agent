# memory.py
import pickle
from collections import defaultdict

class InMemoryDB:
    def __init__(self):
        self.store = defaultdict(list)

    def add_message(self, session_id, message):
        self.store[session_id].append(pickle.dumps(message))

    def get_messages(self, session_id, limit=None):
        all_msgs = [pickle.loads(m) for m in self.store[session_id]]
        if limit:
            return all_msgs[-limit:]
        return all_msgs

    def get_history(self, session_id, n=5):
        return self.get_messages(session_id, limit=n)
